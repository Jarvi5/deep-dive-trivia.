# Deep Dive — Custom Trivia Game

A browser-based, pixel-art-inspired underwater trivia game. The game is self-contained: the artwork is embedded in `index.html`, and no build tools or dependencies are required.

## Publish with GitHub Pages

1. Create a new **public** GitHub repository (for example, `deep-dive-trivia`).
2. Upload `index.html` to the **root** of the repository.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to finish deploying. Your site URL will appear in the Pages settings.

## Run locally

Download `index.html` and open it in a modern browser. No server or installation is needed.

## Customize questions

Open the game and choose **EDIT QUESTIONS** (or use the menu button during a game). Each of the seven prompts has a list of accepted answers and a rarity point value. Save the deck; it is stored in that browser using local storage.

To make your custom deck the default for everyone who visits your published site, edit the `sample` array near the start of the JavaScript in `index.html` and commit the updated file.

## Notes

- The project is intentionally a single-file static site so GitHub Pages can host it without a framework or build step.
- The pixel-art scene is original generated artwork inspired by the screenshot supplied as a visual reference. It is not Krillion's original artwork.
- The game uses custom sample questions and answer banks. Replace them with questions and accepted answers you have permission to use.
